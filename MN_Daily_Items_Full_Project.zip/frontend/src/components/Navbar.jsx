import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <div className="w-full bg-orange-500 p-4 text-white flex justify-between">
      <Link to="/" className="text-2xl font-bold">MN Daily Items</Link>
      <div className="flex gap-4">
        <Link to="/cart">Cart</Link>
        <Link to="/login">Login</Link>
      </div>
    </div>
  );
}
