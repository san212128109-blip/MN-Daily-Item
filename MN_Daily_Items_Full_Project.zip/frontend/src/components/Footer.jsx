export default function Footer() {
  return (
    <div className="w-full bg-gray-800 text-white text-center p-4">
      &copy; 2025 MN Daily Items
    </div>
  );
}
