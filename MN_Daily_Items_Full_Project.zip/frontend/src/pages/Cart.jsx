export default function Cart() {
  return <div className="p-4">Your Cart</div>;
}
