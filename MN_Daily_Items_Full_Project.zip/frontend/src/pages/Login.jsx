export default function Login() {
  return <div className="p-4">Login Page</div>;
}
