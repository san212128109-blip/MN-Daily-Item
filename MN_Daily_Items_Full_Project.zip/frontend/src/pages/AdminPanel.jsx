export default function AdminPanel() {
  return <div className="p-4">Admin Panel - Manage Products & Users</div>;
}
