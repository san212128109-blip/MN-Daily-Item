export default function ProductDetails() {
  return <div className="p-4">Product Details Page</div>;
}
