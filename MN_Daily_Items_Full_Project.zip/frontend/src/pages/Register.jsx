export default function Register() {
  return <div className="p-4">Register Page</div>;
}
